import React from 'react';

class Authentication extends React.Component {
    render() {
        return (
            <div>
                Auth
            </div>
        );
    }
}

export default Authentication;