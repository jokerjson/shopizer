export const search = payload => ({
  type: 'Search',
  payload
})