export const cartkey = payload => ({
  type: 'Cartkey',
  payload
})

export const removeCartkey = payload => ({
  type: 'RemoveCartkey',
  payload
})