export const api = ({
  type: 'API'
})