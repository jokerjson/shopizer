
export const cartTo = payload => ({
  type: 'ADD_Chart',
  payload
})

export const removeInCart = payload => ({
  type: 'Remove_Chart',
  payload
})