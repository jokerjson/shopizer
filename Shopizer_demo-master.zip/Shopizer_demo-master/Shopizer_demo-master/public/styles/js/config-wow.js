(function ($) {
    "use strict";
    // Use strict

     new WOW().init();
})(jQuery);