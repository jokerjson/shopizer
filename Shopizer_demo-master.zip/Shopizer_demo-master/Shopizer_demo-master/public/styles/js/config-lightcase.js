(function ($) {
    "use strict";
    // Use strict

    $('a[data-rel^="footerGallery:slideshow"]').lightcase();
    $('a[data-rel^="instagramwidget:slideshow"]').lightcase();
    
})(jQuery);